import {View, Text} from 'react-native'

export default ()=>{
    return(
        <View>
            <Text>PRUEBA HASTA BUILDEAR</Text>
        </View>
    )
}